/** (C) 8 of September, 2025 Burt Sumner */
/** Free to use, but this copyright message must remain here */

#ifndef _GBADEV_TYPES_
#define _GBADEV_TYPES_


#include "GBAdev_util_macros.h"

#ifdef __cplusplus
extern "C" {
#endif  /* C++ Name mangler guard */
typedef unsigned char           u8;
typedef unsigned short int      u16;
typedef unsigned long int       u32;
typedef unsigned long long int  u64;

typedef char                    i8;
typedef short int               i16;
typedef long int                i32;
typedef long long int           i64;
typedef _Bool BOOL;

typedef struct s_dma_cnt_fields {
  u32 ntransfers : 16;
  u32 IGNORE_PAD0 : 5;
  u32 dest_adjustment : 2;
  u32 src_adjustment : 2;
  BOOL repeat : 1;
  BOOL word_sized_chunks : 1;
  BOOL IGNORE_PAD1 : 1;
  u32 timing_mode : 2;
  BOOL interrupt_upon_completion : 1;
  BOOL enable : 1;
} ALIGN(2) PACKED DMA_CNT_Fields_t;

typedef struct s_tm_cnt_fields {
  u32 freq:2;
  BOOL cascade_mode:1;
  u32 IGNORE_PAD0:3;
  BOOL interrupt_upon_completion:1;
  BOOL enable:1;
  BOOL IGNORE_PAD1;
} ALIGN(2) PACKED Timer_CNT_Fields_t;
  
typedef struct s_dma_handle {
  const void *src;
  void *dst;
  union { u32 raw; DMA_CNT_Fields_t fields; } cnt_reg;
} DMA_Handle_t;

typedef struct s_tm_handle {
  u16 data;
  union { u16 raw; Timer_CNT_Fields_t fields; } cnt_reg;
} Timer_Handle_t;

typedef union u_obj_attr0 {
  u16 raw;
  struct {
    u32 y             : 8;
    BOOL affine_mode  : 1;
    BOOL disable      : 1;
    u32 mode          : 2;
    BOOL mosaic       : 1;
    BOOL pal_8bpp     : 1;
    u32 shape         : 2;
  } ALIGN(2) PACKED regular;
  struct {
    u32 y             : 8;
    BOOL affine_mode  : 1;
    BOOL double_size  : 1;
    u32 mode          : 2;
    BOOL mosaic       : 1;
    BOOL pal_8bpp     : 1;
    u32 shape         : 2;
  } ALIGN(2) PACKED affine;
  struct {
    u32 y             : 8;
    BOOL affine_mode  : 1;
    BOOL IGNORE_PAD0  : 1;
    u32 mode          : 2;
    BOOL mosaic       : 1;
    BOOL pal_8bpp     : 1;
    u32 shape         : 2;
  } ALIGN(2) PACKED shared;
} Obj_Attr_Fields0_t;

typedef union u_obj_attr1 {
  u16 raw;
  struct {
    u32 x : 9;
    u32 IGNORE_PAD0 : 3;
    BOOL hflip : 1;
    BOOL vflip : 1;
    u32 obj_size : 2;
  } ALIGN(2) PACKED regular;
  struct {
    u32 x : 9;
    u32 affine_idx : 5;
    u32 obj_size : 2;
  } ALIGN(2) PACKED affine;
  struct {
    u32 x : 9;
    u32 IGNORE_PAD0 : 5;
    u32 obj_size : 2;
  } ALIGN(2) PACKED shared;
} Obj_Attr_Fields1_t;

typedef struct s_obj_attr2 {
  u32 sprite_idx : 10;
  u32 priority : 2;
  u32 pal16_bank : 4;
} ALIGN(2) PACKED Obj_Attr_Fields2_t;



typedef struct s_obj_attr {
  Obj_Attr_Fields0_t attr0;
  Obj_Attr_Fields1_t attr1;
  Obj_Attr_Fields2_t attr2;
  u16 IGNORE_PAD;
} ALIGN(4) Obj_Attr_t;

typedef struct s_obj_affine_transform {
  u16 IGNORE_PAD0[3], 
      pa, 
      IGNORE_PAD1[3],
      pb,
      IGNORE_PAD2[3],
      pc,
      IGNORE_PAD3[3],
      pd;
} ALIGN(4) Obj_Affine_Transform_t;

typedef struct s_spr_tile_4bpp {
  u32 data[8];
} Tile4_t;

typedef struct s_spr_tile_8bpp {
  u32 data[16];
} Tile8_t;

typedef Tile4_t Tile4_Block_t[512];
typedef Tile8_t Tile8_Block_t[256];



#ifdef __cplusplus
}
#endif  /* C++ Name mangler guard */

#endif  /* _GBADEV_TYPES_ */
