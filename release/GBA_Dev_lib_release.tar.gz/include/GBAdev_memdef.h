/** (C) 7 of September, 2025 Burt Sumner */
/** Free to use, but this copyright message must remain here */

#ifndef _GBADEV_MEMDEF_
#define _GBADEV_MEMDEF_

#ifdef __cplusplus
extern "C" {
#endif  /* C++ Name mangler guard */

#define MEM_IO            0x04000000
#define MEM_PAL           0x05000000
#define MEM_VRAM          0x06000000
#define MEM_OAM           0x07000000
#define MEM_ROM           0x08000000
#define MEM_SRAM          0x0E000000

#define M4_PAGE_SIZE      0x9600
#define M5_PAGE_SIZE      0xA000

#define M3_SCREEN_HEIGHT  160
#define M3_SCREEN_WIDTH   240

#define M4_SCREEN_HEIGHT  160
#define M4_SCREEN_WIDTH   240

#define M5_SCREEN_HEIGHT  128
#define M5_SCREEN_WIDTH   160

#define PAL_BG_SIZE       0x0200
#define PAL_OBJ_SIZE      0x0200

#define VRAM_BG_SIZE      0x10000
#define VRAM_OBJ_SIZE     0x08000

#define M3_SIZE           0x12C00
#define M4_SIZE           0x09600
#define M5_SIZE           0x0A000
#define BMP_PAGE_SIZE     0x0A000


#define KEY_A             0x0001
#define KEY_B             0x0002
#define KEY_SEL           0x0004
#define KEY_START         0x0008
#define KEY_RIGHT         0x0010
#define KEY_LEFT          0x0020
#define KEY_UP            0x0040
#define KEY_DOWN          0x0080
#define KEY_R             0x0100
#define KEY_L             0x0200
#define KEY_MASK          0x03FF

#define DPY_CNT_MODE_MASK   0x0007
#define DPY_CNT_GB          0x0008
#define DPY_CNT_PAGE_SEL    0x0010
#define DPY_CNT_OAM_HBL     0x0020
#define DPY_CNT_OBJ_1D      0x0040
#define DPY_CNT_BLANK       0x0080
#define DPY_CNT_BG0         0x0100
#define DPY_CNT_BG1         0x0200
#define DPY_CNT_BG2         0x0400
#define DPY_CNT_BG3         0x0800
#define DPY_CNT_OBJ         0x1000
#define DPY_CNT_WIN0        0x2000
#define DPY_CNT_WIN1        0x4000
#define DPY_CNT_WIN_OBJ     0x8000

#define DPY_STAT_IN_VBL       0x0001
#define DPY_STAT_IN_HBL       0x0002
#define DPY_STAT_IN_VCOUNT    0x0004
#define DPY_STAT_VBL_IRQ      0x0008
#define DPY_STAT_HBL_IRQ      0x0010
#define DPY_STAT_VCOUNT_IRQ   0x0020
#define DPY_STAT_VCOUNT_MASK  0xFF00




#ifdef __cplusplus
}
#endif  /* C++ Name mangler guard */

#endif  /* _GBADEV_MEMDEF_ */
