/** (C) 7 of September, 2025 Burt Sumner */
/** Free to use, but this copyright message must remain here */

#ifndef _GBADEV_FUNCTIONS_
#define _GBADEV_FUNCTIONS_

#include <GBAdev_types.h>
#ifdef __cplusplus
extern "C" {
#endif  /* C++ Name mangler guard */

EWRAM_CODE BOOL SRAM_Write(const void *src, u32 size, u32 offset);
EWRAM_CODE BOOL SRAM_Read(void *dst, u32 size, u32 offset);

IWRAM_CODE void Fast_Memcpy32(void *dst, const void *src, u32 word_ct);
IWRAM_CODE void Fast_Memset32(void *dst, u32 fill_word, u32 word_ct);

BOOL OAM_Init(Obj_Attr_t *obj_attrs, u32 count);

INLN void OAM_Copy(Obj_Attr_t *obj_attrs, const Obj_Attr_t *src, u32 count);

INLN void OAM_Copy(Obj_Attr_t *obj_attrs, const Obj_Attr_t *src, u32 count) {
  Fast_Memcpy32(obj_attrs, src, count<<1);
}





#ifdef __cplusplus
}
#endif  /* C++ Name mangler guard */

#endif  /* _GBADEV_FUNCTIONS_ */
